package model;

/**
 * player observer interface.
 */
public interface PlayerObserver {
  void playerHasNewCard();
}
